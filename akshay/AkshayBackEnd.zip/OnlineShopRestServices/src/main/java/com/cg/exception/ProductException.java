package com.cg.exception;


/*
 * author name= Akshay
 * Class Name=Product Controller
 * Number of Methods=2
 *date of creation = 08/08/2018
 * 
 */
public class ProductException extends Exception {

	public  ProductException(){
		super();
	}
	public ProductException(String message) {
		super(message);
	}
	
}
